package com.garo.translate;

import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Check if user is already logged in
        prefs = getSharedPreferences("GaroAI_Auth", MODE_PRIVATE);
        if (prefs.getBoolean("isLoggedIn", false)) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
            return; // Stop rendering login screen
        }

        setContentView(R.layout.activity_login);

        // 2. Start Pulse Animation on Logo
        TextView logoText = findViewById(R.id.logoText);
        Animation pulseAnim = AnimationUtils.loadAnimation(this, R.anim.pulse);
        logoText.startAnimation(pulseAnim);

        // 3. Handle Google Login Click
        LinearLayout btnGoogleLogin = findViewById(R.id.btnGoogleLogin);
        btnGoogleLogin.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startGoogleLogin();
				}
			});
    }

    private void startGoogleLogin() {
        try {
            // Using reflection to bypass AIDE compilation limitations while safely calling Android's native Account Picker
            Intent intent;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                intent = (Intent) AccountManager.class.getMethod("newChooseAccountIntent", 
																 android.accounts.Account.class, java.util.List.class, String[].class, String.class, String.class, String[].class, Bundle.class)
                    .invoke(null, null, null, new String[]{"com.google"}, null, null, null, null);
            } else {
                intent = (Intent) AccountManager.class.getMethod("newChooseAccountIntent", 
																 android.accounts.Account.class, java.util.ArrayList.class, String[].class, boolean.class, String.class, String.class, String[].class, Bundle.class)
                    .invoke(null, null, null, new String[]{"com.google"}, false, null, null, null, null);
            }
            startActivityForResult(intent, 1001);
        } catch (Exception e) {
            // Fallback if device has no Google accounts or custom OS blocks it
            saveLoginSession("Guest User");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null) {
            // Extract selected Google Email natively!
            String accountEmail = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (accountEmail != null) {
                saveLoginSession(accountEmail);
            } else {
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveLoginSession(String email) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("isLoggedIn", true);
        editor.putString("userEmail", email);
        editor.apply();

        Toast.makeText(this, "Welcome, " + email, Toast.LENGTH_SHORT).show();
        startActivity(new Intent(LoginActivity.this, MainActivity.class));
        finish();
    }
}
