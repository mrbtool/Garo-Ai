package com.garo.translate;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    // API Configurations
    private static final String API_KEY = "AIzaSyDjdJB3udBjNLUCJy9gj415pw0A37TTb38"; 
    private static final String GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=" + API_KEY;
    private static final String FIREBASE_PROJECT_ID = "garo-ai";

    // View References
    private View sectionTranslate, sectionChat;
    private TextView headerTitle;
    private ImageView iconTranslate, iconChat, btnLogout;
    private TextView textTranslate, textChat;
    private LinearLayout navTranslate, navChat, chatContainer;

    private EditText inputText;
    private Button btnTranslate;
    private TextView outputText;

    private EditText inputChat;
    private ImageView btnSendChat;
    private ScrollView chatScroll;

    private JSONArray chatHistory;

    // User Session
    private String currentUserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); 

        // Load User Session from LoginActivity
        SharedPreferences prefs = getSharedPreferences("GaroAI_Auth", MODE_PRIVATE);
        currentUserEmail = prefs.getString("userEmail", "Unknown User");

        initViews();
        setupNavigation();

        chatHistory = new JSONArray();
        addChatMessage("Hello! I am your AI Assistant. I can understand and speak both English and Garo. How can I help you today?", false);

        // LOGOUT BUTTON LOGIC
        btnLogout.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Clear Session
					SharedPreferences prefs = getSharedPreferences("GaroAI_Auth", MODE_PRIVATE);
					prefs.edit().clear().apply();

					Toast.makeText(MainActivity.this, "Logged Out", Toast.LENGTH_SHORT).show();
					startActivity(new Intent(MainActivity.this, LoginActivity.class));
					finish(); 
				}
			});

        // TRANSLATE BUTTON LOGIC
        btnTranslate.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String text = inputText.getText().toString().trim();
					if (!text.isEmpty()) {
						btnTranslate.setEnabled(false);
						btnTranslate.setAlpha(0.5f);
						outputText.setText("Searching smart database...");
						checkDatabaseAndTranslate(text);
					} else {
						Toast.makeText(MainActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
					}
				}
			});

        // SEND CHAT BUTTON LOGIC
        btnSendChat.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String text = inputChat.getText().toString().trim();
					if (!text.isEmpty()) {
						inputChat.setText("");
						addChatMessage(text, true);
						processChat(text);
					}
				}
			});
    }

    private void initViews() {
        headerTitle = findViewById(R.id.headerTitle);
        btnLogout = findViewById(R.id.btnLogout);
        sectionTranslate = findViewById(R.id.sectionTranslate);
        sectionChat = findViewById(R.id.sectionChat);
        navTranslate = findViewById(R.id.navTranslate);
        navChat = findViewById(R.id.navChat);
        iconTranslate = findViewById(R.id.iconTranslate);
        iconChat = findViewById(R.id.iconChat);
        textTranslate = findViewById(R.id.textTranslate);
        textChat = findViewById(R.id.textChat);
        inputText = findViewById(R.id.inputText);
        btnTranslate = findViewById(R.id.btnTranslate);
        outputText = findViewById(R.id.outputText);
        inputChat = findViewById(R.id.inputChat);
        btnSendChat = findViewById(R.id.btnSendChat);
        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatScroll);
    }

    private void setupNavigation() {
        navTranslate.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { switchTab(true); }
			});
        navChat.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) { switchTab(false); }
			});
    }

    private void switchTab(boolean isTranslate) {
        sectionTranslate.setVisibility(isTranslate ? View.VISIBLE : View.GONE);
        sectionChat.setVisibility(isTranslate ? View.GONE : View.VISIBLE);
        headerTitle.setText(isTranslate ? "Translate" : "AI Chat");
        int colorPrimary = Color.parseColor("#4361EE");
        int colorSecondary = Color.parseColor("#8D99AE");
        textTranslate.setTextColor(isTranslate ? colorPrimary : colorSecondary);
        textTranslate.setTypeface(null, isTranslate ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        iconTranslate.setColorFilter(isTranslate ? colorPrimary : colorSecondary);
        textChat.setTextColor(!isTranslate ? colorPrimary : colorSecondary);
        textChat.setTypeface(null, !isTranslate ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        iconChat.setColorFilter(!isTranslate ? colorPrimary : colorSecondary);
    }

    private void addChatMessage(String message, boolean isUser) {
        TextView tv = new TextView(this);
        tv.setText(message);
        tv.setTextSize(16f);
        tv.setPadding(32, 24, 32, 24);
        tv.setBackgroundResource(isUser ? R.drawable.bg_chat_user : R.drawable.bg_chat_ai);
        tv.setTextColor(isUser ? Color.WHITE : Color.parseColor("#2B2D42"));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = isUser ? Gravity.END : Gravity.START;
        params.setMargins(0, 8, 0, 16);
        tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.75));
        tv.setLayoutParams(params);
        chatContainer.addView(tv);
        chatScroll.post(new Runnable() {
				@Override
				public void run() { chatScroll.fullScroll(View.FOCUS_DOWN); }
			});
    }

    // ==========================================
    // 1. SMART DATABASE SEARCH (REST API)
    // ==========================================
    private void checkDatabaseAndTranslate(final String originalText) {
        final String normalizedText = originalText.toLowerCase().trim();
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						String queryUrl = "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + "/databases/(default)/documents:runQuery";

						JSONObject payload = new JSONObject();
						JSONObject structuredQuery = new JSONObject();
						JSONArray from = new JSONArray();
						JSONObject collection = new JSONObject();
						collection.put("collectionId", "translations");
						from.put(collection);
						structuredQuery.put("from", from);

						JSONObject where = new JSONObject();
						JSONObject fieldFilter = new JSONObject();
						JSONObject field = new JSONObject();
						field.put("fieldPath", "normalized");
						fieldFilter.put("field", field);
						fieldFilter.put("op", "EQUAL");
						JSONObject value = new JSONObject();
						value.put("stringValue", normalizedText);
						fieldFilter.put("value", value);
						where.put("fieldFilter", fieldFilter);
						structuredQuery.put("where", where);
						payload.put("structuredQuery", structuredQuery);

						String response = sendPostRequest(queryUrl, payload.toString());
						JSONArray responseArray = new JSONArray(response);

						if (responseArray.length() > 0 && responseArray.getJSONObject(0).has("document")) {
							// Found in Database!
							JSONObject doc = responseArray.getJSONObject(0).getJSONObject("document");
							JSONObject fields = doc.getJSONObject("fields");
							final String savedTranslation = fields.getJSONObject("translated").getString("stringValue");

							runOnUiThread(new Runnable() {
									@Override
									public void run() {
										outputText.setText(savedTranslation + "");
										btnTranslate.setEnabled(true);
										btnTranslate.setAlpha(1.0f);
									}
								});
						} else {
							// Not found, use Gemini
							runOnUiThread(new Runnable() {
									@Override
									public void run() { outputText.setText("Translating with AI..."); }
								});
							processTranslation(originalText, normalizedText);
						}
					} catch (Exception e) {
						processTranslation(originalText, normalizedText);
					}
				}
			}).start();
    }

    // ==========================================
    // 2. GEMINI API & SAVE TO DB (REST API)
    // ==========================================
    private void processTranslation(final String englishText, final String normalizedText) {
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						String prompt = "Translate the following English text to the Garo language. Only provide the translation, do not provide any extra explanations: " + englishText;
						JSONArray contents = new JSONArray();
						contents.put(buildMessageObject("user", prompt));

						// 1. Get Translation
						JSONObject geminiPayload = new JSONObject();
						geminiPayload.put("contents", contents);
						String geminiResponseRaw = sendPostRequest(GEMINI_URL, geminiPayload.toString());

						JSONObject jsonResponse = new JSONObject(geminiResponseRaw);
						final String result = jsonResponse.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");

						runOnUiThread(new Runnable() {
								@Override
								public void run() {
									outputText.setText(result);
									btnTranslate.setEnabled(true);
									btnTranslate.setAlpha(1.0f);
								}
							});

						// 2. Save translation AND USER EMAIL to Firestore
						String saveUrl = "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + "/databases/(default)/documents/translations";
						JSONObject dbPayload = new JSONObject();
						JSONObject fields = new JSONObject();

						JSONObject origObj = new JSONObject(); origObj.put("stringValue", englishText);
						JSONObject normObj = new JSONObject(); normObj.put("stringValue", normalizedText);
						JSONObject transObj = new JSONObject(); transObj.put("stringValue", result);
						JSONObject timeObj = new JSONObject(); timeObj.put("integerValue", String.valueOf(System.currentTimeMillis()));
						JSONObject emailObj = new JSONObject(); emailObj.put("stringValue", currentUserEmail); // Saving Email!

						fields.put("original", origObj);
						fields.put("normalized", normObj);
						fields.put("translated", transObj);
						fields.put("timestamp", timeObj);
						fields.put("user_email", emailObj);
						dbPayload.put("fields", fields);

						sendPostRequest(saveUrl, dbPayload.toString());

					} catch (Exception e) {
						showErrorOnUI("Error: " + e.getMessage(), true);
					}
				}
			}).start();
    }

    // ==========================================
    // 3. AI CHAT & SAVE TO DB
    // ==========================================
    private void processChat(final String userText) {
        new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						String systemContext = "System Instruction: You are a friendly AI. You speak perfectly in English and Garo. IMPORTANT: You were created by a developer named 'Mr Bush X'. If anyone asks who made you, created you, or developed you, you MUST ALWAYS answer that you were created by Mr Bush X. User says: " + userText;
						chatHistory.put(buildMessageObject("user", systemContext));

						JSONObject payload = new JSONObject();
						payload.put("contents", chatHistory);

						String responseRaw = sendPostRequest(GEMINI_URL, payload.toString());
						JSONObject jsonResponse = new JSONObject(responseRaw);
						final String aiResponse = jsonResponse.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");

						chatHistory.put(buildMessageObject("model", aiResponse));

						runOnUiThread(new Runnable() {
								@Override
								public void run() { addChatMessage(aiResponse, false); }
							});

						// Save chat log AND USER EMAIL to Firestore
						String logUrl = "https://firestore.googleapis.com/v1/projects/" + FIREBASE_PROJECT_ID + "/databases/(default)/documents/ai_chat_logs";
						JSONObject dbPayload = new JSONObject();
						JSONObject fields = new JSONObject();

						JSONObject userObj = new JSONObject(); userObj.put("stringValue", userText);
						JSONObject aiObj = new JSONObject(); aiObj.put("stringValue", aiResponse);
						JSONObject timeObj = new JSONObject(); timeObj.put("integerValue", String.valueOf(System.currentTimeMillis()));
						JSONObject emailObj = new JSONObject(); emailObj.put("stringValue", currentUserEmail); // Saving Email!

						fields.put("user_text", userObj);
						fields.put("ai_response", aiObj);
						fields.put("timestamp", timeObj);
						fields.put("user_email", emailObj);
						dbPayload.put("fields", fields);

						sendPostRequest(logUrl, dbPayload.toString());

					} catch (Exception e) {
						showErrorOnUI("Connection Error. Please try again.", false);
					}
				}
			}).start();
    }

    // --- Helper Methods ---
    private JSONObject buildMessageObject(String role, String text) throws Exception {
        JSONObject textObj = new JSONObject(); textObj.put("text", text);
        JSONArray partsArray = new JSONArray(); partsArray.put(textObj);
        JSONObject msgObj = new JSONObject(); msgObj.put("role", role); msgObj.put("parts", partsArray);
        return msgObj;
    }

    private String sendPostRequest(String urlString, String jsonPayload) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        os.write(jsonPayload.getBytes("UTF-8"));
        os.close();

        int responseCode = conn.getResponseCode();
        BufferedReader in;
        if (responseCode >= 200 && responseCode < 300) {
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }

        StringBuilder response = new StringBuilder();
        String inputLine;
        while ((inputLine = in.readLine()) != null) { response.append(inputLine); }
        in.close();

        if (responseCode >= 200 && responseCode < 300) {
            return response.toString();
        } else {
            throw new Exception("HTTP Error: " + responseCode);
        }
    }

    private void showErrorOnUI(final String msg, final boolean isTranslate) {
        runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (isTranslate) {
						outputText.setText(msg);
						btnTranslate.setEnabled(true);
						btnTranslate.setAlpha(1.0f);
					} else {
						addChatMessage(msg, false);
					}
				}
			});
    }
}
